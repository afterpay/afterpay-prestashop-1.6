
<?php 

echo 'Your Afterpay order has been cancelled';

?>
